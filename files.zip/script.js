document.getElementById('year').textContent = new Date().getFullYear();

// Contact form: opens the visitor's email app with the message filled in.
// To send without an email app, replace this with a form service (e.g. Formspree).
var form = document.getElementById('contact-form');
form.addEventListener('submit', function (e) {
  e.preventDefault();
  var note = form.querySelector('.form-note');
  var name = form.name.value.trim();
  var email = form.email.value.trim();
  var message = form.message.value.trim();
  if (!name || !email || !message) {
    note.textContent = 'Please fill in your name, email and message.';
    return;
  }
  var body = message + '\n\n' + name + '\n' + email;
  window.location.href = 'mailto:info@ansarsequoia.com?subject=' +
    encodeURIComponent('Website inquiry from ' + name) +
    '&body=' + encodeURIComponent(body);
  note.textContent = 'Opening your email app. Please press send to complete your message.';
});
